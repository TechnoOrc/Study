package kr.co.ictedu.board.free;

public class FreeBoardDTO {

	private String board_no;
	private String title;
	private String writer;
	private String pwd;
	private String contents;
	private String write_date;
	private String view_cnt;
	

	public String toString() {
		return board_no + " : " + title + " : " + writer;
	}

	public String getBoard_no() {
		return board_no;
	}
	public void setBoard_no(String board_no) {
		this.board_no = board_no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getWrite_date() {
		return write_date;
	}
	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}
	public String getView_cnt() {
		return view_cnt;
	}
	
	public void setView_cnt(String view_cnt) {
		this.view_cnt = view_cnt;
	}

}//class
